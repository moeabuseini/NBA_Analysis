*The goal of the project is to give students an opportunity to develop an end-to-end data
science project of their choice. By the end of the course you will have engineered a
piece of data-driven software that helps users analyze and visualize a set of data while
discovering a set of previously unseen correlations.*
